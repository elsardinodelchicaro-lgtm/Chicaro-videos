CHICARO VIDEO — Proyecto Android nativo v0.3

Incluye:
- Proyecto Android Studio (Java + WebView).
- Descarga de enlaces directos HTTPS a archivos de vídeo, cuando el servidor entrega vídeo y permite la conexión.
- Importación de vídeos desde el selector de Android.
- Biblioteca de archivos guardados en la carpeta privada de la aplicación:
  Android/data/com.chicaro.video/files/Movies/CHICARO VIDEO
- Historial local y UI premium.

IMPORTANTE SOBRE LA CARPETA:
La carpeta es almacenamiento externo específico de la app. Android la protege y algunos gestores de archivos no permiten navegar a Android/data. Los archivos pertenecen a CHICARO VIDEO y normalmente se eliminan al desinstalar la aplicación. Si se necesita una carpeta pública visible en Galería/Movies, hay que añadir exportación mediante MediaStore como función separada.

COMPILAR APK:
1. Instala Android Studio y Android SDK Platform 35.
2. Abre esta carpeta (CHICARO_VIDEO_Android) en Android Studio.
3. Espera a que Gradle sincronice.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración aparecerá en app/build/outputs/apk/debug/app-debug.apk.

Esta sesión no dispone de Android SDK/Gradle instalado, por lo que no es posible compilar ni verificar un APK binario aquí. El proyecto fuente queda preparado para compilar en Android Studio.

Limitaciones de descarga:
- No descarga vídeos desde páginas de publicaciones de X, YouTube o Instagram por extracción no autorizada.
- Para esas plataformas abre el contenido y debes usar la función oficial de descarga/guardado cuando exista y esté permitida.
- La descarga directa HTTPS solo funciona cuando el URL es un archivo y el servidor responde con un tipo de contenido de vídeo o binario.
- No evita DRM, autenticación, controles de acceso ni restricciones técnicas.
