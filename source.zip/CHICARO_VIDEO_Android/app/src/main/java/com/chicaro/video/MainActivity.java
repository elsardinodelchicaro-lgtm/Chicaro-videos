package com.chicaro.video;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.widget.Toast;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private File mediaDir;
    private static final int PICK_VIDEO = 701;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        mediaDir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "CHICARO VIDEO");
        if (!mediaDir.exists()) mediaDir.mkdirs();
        web = new WebView(this);
        web.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.addJavascriptInterface(new AndroidStorage(), "AndroidStorage");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("file:///android_asset/")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception ignored) {}
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("video/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(intent, PICK_VIDEO);
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/www/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO) {
            if (fileCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int n = data.getClipData().getItemCount(); results = new Uri[n];
                        for (int i=0;i<n;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    } else if (data.getData() != null) results = new Uri[]{data.getData()};
                }
                fileCallback.onReceiveValue(results); fileCallback = null;
            }
            if (resultCode == RESULT_OK && data != null) {
                executor.execute(() -> {
                    try {
                        if (data.getClipData()!=null) {
                            for(int i=0;i<data.getClipData().getItemCount();i++) copyUri(data.getClipData().getItemAt(i).getUri());
                        } else if(data.getData()!=null) copyUri(data.getData());
                        runOnUiThread(() -> { toast("Vídeo(s) guardado(s) en CHICARO VIDEO"); if(web!=null) web.evaluateJavascript("AndroidStorage.listVideos()",null); });
                    } catch(Exception e) { runOnUiThread(() -> toast("No se pudo importar el vídeo")); }
                });
            }
        }
    }

    private void copyUri(Uri uri) throws Exception {
        String name = displayName(uri);
        File out = uniqueFile(name);
        try(InputStream in=getContentResolver().openInputStream(uri); OutputStream os=new FileOutputStream(out)) {
            if(in==null) throw new IOException("No se pudo abrir el archivo");
            byte[] buf=new byte[65536]; int n; while((n=in.read(buf))>0) os.write(buf,0,n);
        }
    }
    private String displayName(Uri uri) {
        String name="video_"+System.currentTimeMillis()+".mp4";
        try(Cursor c=getContentResolver().query(uri,null,null,null,null)) {
            if(c!=null && c.moveToFirst()) { int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(i>=0) name=c.getString(i); }
        } catch(Exception ignored) {}
        return name;
    }
    private File uniqueFile(String name) {
        name=name.replaceAll("[\\\\/:*?\"<>|]","_");
        File f=new File(mediaDir,name); int i=1;
        while(f.exists()) { int dot=name.lastIndexOf('.'); String stem=dot>0?name.substring(0,dot):name; String ext=dot>0?name.substring(dot):".mp4"; f=new File(mediaDir,stem+"_"+(i++)+ext); }
        return f;
    }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }

    public class AndroidStorage {
        @JavascriptInterface public void pickVideos() { runOnUiThread(() -> {
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("video/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); startActivityForResult(i,PICK_VIDEO);
        }); }
        @JavascriptInterface public void listVideos() {
            executor.execute(() -> {
                JSONArray arr=new JSONArray(); File[] files=mediaDir.listFiles();
                if(files!=null) for(File f:files) if(f.isFile()) try { JSONObject o=new JSONObject(); o.put("name",f.getName()); o.put("size",f.length()); arr.put(o); } catch(Exception ignored){}
                String js="window.onNativeFolderListed && window.onNativeFolderListed("+JSONObject.quote(arr.toString())+")";
                runOnUiThread(() -> web.evaluateJavascript(js,null));
            });
        }
        @JavascriptInterface public void downloadVideo(String url, String name) {
            executor.execute(() -> {
                boolean ok=false; String message="No se pudo descargar el archivo.";
                HttpURLConnection c=null;
                try {
                    URL u=new URL(url); if(!"https".equalsIgnoreCase(u.getProtocol())) throw new IOException("Solo se permiten enlaces HTTPS");
                    c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setInstanceFollowRedirects(true); c.setRequestProperty("User-Agent","CHICARO-VIDEO/0.3");
                    int code=c.getResponseCode(); if(code<200||code>=300) throw new IOException("Respuesta HTTP "+code);
                    String type=c.getContentType(); if(type==null || !(type.toLowerCase().startsWith("video/") || type.toLowerCase().contains("octet-stream"))) throw new IOException("El servidor no entregó un vídeo");
                    File out=uniqueFile(name==null||name.trim().isEmpty()?"video.mp4":name);
                    try(InputStream in=c.getInputStream(); OutputStream os=new FileOutputStream(out)) {
                        byte[] buf=new byte[65536]; int n; while((n=in.read(buf))>0) os.write(buf,0,n);
                    }
                    ok=true; message="Vídeo guardado en la carpeta CHICARO VIDEO.";
                } catch(Exception e) { message="Descarga no disponible: "+e.getMessage(); }
                finally { if(c!=null)c.disconnect(); }
                final boolean success=ok; final String msg=message;
                runOnUiThread(() -> { web.evaluateJavascript("window.onNativeDownloadFinished && window.onNativeDownloadFinished("+success+","+JSONObject.quote(msg)+")",null); });
            });
        }
        @JavascriptInterface public void openVideo(String name) {
            runOnUiThread(() -> {
                File f=new File(mediaDir,name);
                if(f.exists()) {
                    toast("Archivo guardado en: "+f.getAbsolutePath());
                }
            });
        }
    }
    @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(web!=null) web.destroy(); executor.shutdown(); super.onDestroy(); }
}
